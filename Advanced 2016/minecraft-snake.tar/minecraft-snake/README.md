-------------------------------------------------------------------------------
Minecraft - Snake Game
Martin O'Hanlon (martin@ohanlonweb.com)
http://www.stuffaboutcode.com
-------------------------------------------------------------------------------

A re-creation of the classic game snake for Minecraft: Pi edition
http://www.stuffaboutcode.com/2013/03/raspberry-pi-minecraft-snake.html

------------------------------------------------------------------------------

Version history
0.1 - first beta release

-------------------------------------------------------------------------------
